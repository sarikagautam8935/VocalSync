package com.blacpythoz.musik.fragments;

import android.support.v4.app.Fragment;

/**
 * Created by deadsec on 10/14/17.
 */

public class MiniPlayerFragment extends Fragment {

}
